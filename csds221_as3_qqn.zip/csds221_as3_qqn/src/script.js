
function final() {
  if ($("#checkin").val()  && $("#checkout").val()) {
    const start = moment($("#checkin").val(), "YYYY-MM-DD");
    const end = moment($("#checkout").val(), "YYYY-MM-DD");
    const numdays = Math.ceil(moment.duration(end.diff(start)).asDays());
    $("#days").val(numdays);
    if ($("#adults").val()) {
      setCost($("#adults").val(), numdays);
    }
  }
}

function setCost(adults, numdays) {
  $("#cost").val(150 * adults * numdays);
}

function reset() {
  $("#main").get(0).reset();
}

function err(message) {
  toastr.error(message);
}

function suc(message) {
  toastr.success(message);
}

function info(message) {
  toastr.info(message);
}
function handle(selector) {
  if ($(`#${selector}`).hasClass("has-error")) {
    $(`#${selector}`).removeClass("has-error");
  }
}

function add(selector, message) {
  $(`#${selector}`).addClass("has-error");
  err(message);
}

$(document).ready(function() {
  toastr.options.closeButton = true;

  $("#checkout").change(() => final());
  $("#reset").click(() => {
    info("All fields are cleared.");
    reset();
  });
  $("#main").submit(event => {
    event.preventDefault();
    let errorOccurred = false;
    if (!$("#username").val() ) {
      errorOccurred = true;
      add("username","Enter username");
    }
    if (!$("#firstname").val()) {
      errorOccurred = true;
      add("firstname", "Enter firstname");
    }
    if (!$("#lastname").val()) {
      errorOccurred = true;
      add("lastname", "Enter lastname");
    }
    if (!$("#phone").val()) {
      errorOccurred = true;
      add("phone", "Enter phone");
    }
    if (!$("#fax").val() ) {
      errorOccurred = true;
      add("fax", "Enter fax");
    }
    if (!$("#email").val()) {
      errorOccurred = true;
      add("email", "Enter email");
    }
     if (!$("#cost").val()) {
            errorOccurred = true
            err("No cost has been calculated.")
        }
      if ($("#cost").val() < 0) {
            errorOccurred = true
            err("Cost is negative.")
        }
    if (!errorOccurred ) {
      suc("Successfully submitted!");
      reset();
    }
  });
  $("#username").change(() => handle("username"));
  $("#firstname").change(() => handle("firstname"));
  $("#lastname").change(() => handle("lastname"));
  $("#phone").change(() => handle("phone"));
  $("#fax").change(() => handle("fax"));
  $("#email").change(() => handle("email"));
});



